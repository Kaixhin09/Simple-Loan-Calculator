function calculateLoan() {
    let principal = parseFloat(document.getElementById("loanAmount").value);
    let annualRate = parseFloat(document.getElementById("interestRate").value);
    let months = parseInt(document.getElementById("loanTerm").value);

    let monthlyRate = (annualRate / 100) / 12; //0.002916 

    // Use Math.pow to calculate (1 + r)^n
    let factor = Math.pow(1 + monthlyRate, months);

    let monthlyPayment = principal * (monthlyRate * factor) / (factor - 1);

    // Show result
    document.getElementById("result").innerText =
        `Monthly Payment: ₱${monthlyPayment.toFixed(2)}`;
}
